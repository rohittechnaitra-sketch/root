<?php
/**
 * Plugin Name: WooCommerce Gift Coupons
 * Plugin URI: https://prettywomanspa.co.uk/
 * Description: Generates Pretty Woman Spa gift voucher PDFs using Dompdf and shortcode.
 * Version: 1.0.0
 * Author: Technaitra
 * Author URI: https://prettywomanspa.co.uk/
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;

// Load Dompdf via Composer autoload
require_once __DIR__ . '/vendor/autoload.php';
use Dompdf\Dompdf;
use Dompdf\Options;

class WooCommerce_Voucher_System {

    public function __construct() {
        // Frontend form
        add_action('woocommerce_before_add_to_cart_button', [$this, 'display_voucher_form']);

        // Cart & Order handling
        add_filter('woocommerce_add_cart_item_data', [$this, 'add_voucher_to_cart'], 10, 2);
        add_filter('woocommerce_get_item_data', [$this, 'display_voucher_in_cart'], 10, 2);
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'save_voucher_to_order'], 10, 4);

        // Order completion
        add_action('woocommerce_thankyou', [$this, 'process_voucher_order'], 10, 1);

        // Email customization
        add_action('woocommerce_email_before_order_table', [$this, 'custom_email_content'], 10, 4);
        add_action('woocommerce_thankyou', [$this, 'send_voucher_email'], 999, 1);

        // Admin settings
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('wp_enqueue_scripts', [$this, 'my_plugin_enqueue_styles']);

    }

    function my_plugin_enqueue_styles() {
    wp_enqueue_style(
        'my-plugin-style', // Handle
        plugin_dir_url(__FILE__) . 'assets/css/style.css', 
        array(), // Dependencies
        rand(1000, 9999), // Version
        'all' // Media
    );
}
    // ---------------- FRONTEND FORM ---------------- //
        public function display_voucher_form() {
            ?>
            <!-- HTML form remains unchanged -->
            <div class="voucher-fields" style="margin-bottom:20px;">
                <!-- Voucher Type -->
                <div style="margin-bottom:15px;">
                    <label><strong>Voucher Type <span style="color:red">*</span></strong></label><br>
                    <select name="voucher_type" id="voucher_type" required style="width:100%; padding:8px;">
                        <option value="">Select type</option>
                        <option value="digital">Digital</option>
                        <option value="physical">Physical</option>
                    </select>
                    <span id="error_voucher_type" class="field-error" style="color:red;display:none;"></span>
                </div>

                <!-- DIGITAL -->
                <div id="digital_wrap" style="display:none; margin-top:10px;">
                    <label><strong>Send To <span style="color:red">*</span></strong></label><br>
                    <select name="digital_send_to" id="digital_send_to" style="width:100%; padding:8px;">
                        <option value="">Select option</option>
                        <option value="myself">Send to Myself</option>
                        <option value="recipient">Send to Recipient</option>
                    </select>
                    <span id="error_digital_send_to" class="field-error" style="color:red;display:none;"></span>

                    <!-- Send to Myself -->
                    <div id="digital_myself" style="display:none; margin-top:10px;">
                        <label>Email <span style="color:red">*</span></label><br>
                        <input type="email" name="digital_myself_email" id="digital_myself_email" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_digital_myself_email" style="color:red;display:none;"></span>

                        <label>Recipient Name <span style="color:red">*</span></label><br>
                        <input type="text" name="digital_myself_name" id="digital_myself_name" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_digital_myself_name" style="color:red;display:none;"></span>

                        <label>Message (120 Character Limit)<span style="color:red">*</span></label><br>
                        <textarea name="digital_myself_message" id="digital_myself_message" rows="4" maxlength="120" style="width:100%; padding:8px; margin-bottom:10px;"></textarea>
                        <span id="error_digital_myself_message" style="color:red;display:none;"></span>
                    </div>

                    <!-- Send to Recipient -->
                    <div id="digital_recipient" style="display:none; margin-top:10px;">
                        <label>Recipient Name <span style="color:red">*</span></label><br>
                        <input type="text" name="digital_recipient_name" id="digital_recipient_name" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_digital_recipient_name" style="color:red;display:none;"></span>

                        <label>Recipient Email <span style="color:red">*</span></label><br>
                        <input type="email" name="digital_recipient_email" id="digital_recipient_email" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_digital_recipient_email" style="color:red;display:none;"></span>

                        <label>Message (120 Character Limit)<span style="color:red">*</span></label><br>
                        <textarea name="digital_recipient_message" id="digital_recipient_message" rows="4" maxlength="120" style="width:100%; padding:8px; margin-bottom:10px;"></textarea>
                        <span id="error_digital_recipient_message" style="color:red;display:none;"></span>

                        <label>From <span style="color:red">*</span></label><br>
                        <input type="email" name="digital_recipient_from" id="digital_recipient_from" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_digital_recipient_from" style="color:red;display:none;"></span>

                        <label>When should the voucher be sent? <span style="color:red">*</span></label><br>
                        <input type="date" name="digital_recipient_date" id="digital_recipient_date" min="<?php echo date('Y-m-d'); ?>" style="width:100%; padding:8px;">
                        <span id="error_digital_recipient_date" style="color:red;display:none;"></span>
                    </div>
                </div>

                <!-- PHYSICAL -->
                <div id="physical_wrap" style="display:none; margin-top:10px;">
                    <label><strong>Delivery Option <span style="color:red">*</span></strong></label><br>
                    <select name="physical_option" id="physical_option" style="width:100%; padding:8px;">
                        <option value="">Select option</option>
                        <option value="collect">Collect</option>
                        <option value="deliver">Deliver</option>
                    </select>
                    <span id="error_physical_option" class="field-error" style="color:red;display:none;"></span>

                    <!-- Collect -->
                    <div id="physical_collect" style="display:none; margin-top:10px;">
                        <label>Recipient Name <span style="color:red">*</span></label><br>
                        <input type="text" name="physical_collect_name" id="physical_collect_name" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_physical_collect_name" style="color:red;display:none;"></span>

                        <label>Message (120 Character Limit)</label><br>
                        <textarea name="physical_collect_message" id="physical_collect_message" rows="4" maxlength="120" style="width:100%; padding:8px; margin-bottom:10px;"></textarea>

                        <label>From <span style="color:red">*</span></label><br>
                        <input type="text" name="physical_collect_from" id="physical_collect_from" style="width:100%; padding:8px;">
                        <span id="error_physical_collect_from" style="color:red;display:none;"></span>
                    </div>

                    <!-- Deliver -->
                    <div id="physical_deliver" style="display:none; margin-top:10px;">
                        <label>Recipient Name <span style="color:red">*</span></label><br>
                        <input type="text" name="physical_deliver_name" id="physical_deliver_name" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_physical_deliver_name" style="color:red;display:none;"></span>

                        <label>Message (120 Character Limit)</label><br>
                        <textarea name="physical_deliver_message" id="physical_deliver_message" rows="4" maxlength="120" style="width:100%; padding:8px; margin-bottom:10px;"></textarea>

                        <label>From <span style="color:red">*</span></label><br>
                        <input type="text" name="physical_deliver_from" id="physical_deliver_from" style="width:100%; padding:8px; margin-bottom:10px;">
                        <span id="error_physical_deliver_from" style="color:red;display:none;"></span>

                        <label>Recipient Address <span style="color:red">*</span></label><br>
                        <textarea name="physical_deliver_address" id="physical_deliver_address" rows="3" style="width:100%; padding:8px;"></textarea>
                        <span id="error_physical_deliver_address" style="color:red;display:none;"></span>
                    </div>
                </div>
            </div>

            <script>
            document.addEventListener("DOMContentLoaded", function(){
                const form = document.querySelector("form.cart");
                const type = document.getElementById("voucher_type");
                const digitalWrap = document.getElementById("digital_wrap");
                const physicalWrap = document.getElementById("physical_wrap");
                const digitalSendTo = document.getElementById("digital_send_to");
                const physicalOption = document.getElementById("physical_option");
                const digitalMyself = document.getElementById("digital_myself");
                const digitalRecipient = document.getElementById("digital_recipient");
                const physicalCollect = document.getElementById("physical_collect");
                const physicalDeliver = document.getElementById("physical_deliver");

                // Function to clear input and textarea fields (excluding selects) and errors
                function clearFormFields() {
                    // Clear all inputs and textareas (not selects)
                    document.querySelectorAll('.voucher-fields input, .voucher-fields textarea')
                        .forEach(el => {
                            el.value = '';
                        });
                    // Clear all error messages
                    document.querySelectorAll('.field-error').forEach(el => {
                        el.textContent = '';
                        el.style.display = 'none';
                    });
                }

                // Clear fields on voucher_type change
                type.addEventListener("change", function(){
                    digitalWrap.style.display = this.value === "digital" ? "block" : "none";
                    physicalWrap.style.display = this.value === "physical" ? "block" : "none";
                    digitalSendTo.value = "";
                    physicalOption.value = "";
                    digitalMyself.style.display = "none";
                    digitalRecipient.style.display = "none";
                    physicalCollect.style.display = "none";
                    physicalDeliver.style.display = "none";
                    clearFormFields(); // Clear inputs and textareas
                });

                // Clear fields on digital_send_to change
                digitalSendTo.addEventListener("change", function(){
                    digitalMyself.style.display = this.value === "myself" ? "block" : "none";
                    digitalRecipient.style.display = this.value === "recipient" ? "block" : "none";
                    clearFormFields(); // Clear inputs and textareas
                });

                // Clear fields on physical_option change
                physicalOption.addEventListener("change", function(){
                    physicalCollect.style.display = this.value === "collect" ? "block" : "none";
                    physicalDeliver.style.display = this.value === "deliver" ? "block" : "none";
                    clearFormFields(); // Clear inputs and textareas
                });

                form.addEventListener("submit", function(e){
                    let hasError = false;
                    document.querySelectorAll(".field-error").forEach(el => el.style.display = "none");

                    if(!type.value){
                        document.getElementById("error_voucher_type").textContent = "Please select voucher type.";
                        document.getElementById("error_voucher_type").style.display = "block";
                        hasError = true;
                    }

                    if(type.value === "digital"){
                        if(!digitalSendTo.value){
                            document.getElementById("error_digital_send_to").textContent = "Please select send option.";
                            document.getElementById("error_digital_send_to").style.display = "block";
                            hasError = true;
                        }
                        if(digitalSendTo.value === "myself"){
                            ["email","name","message"].forEach(f=>{
                                const el = document.getElementById("digital_myself_"+f);
                                const err = document.getElementById("error_digital_myself_"+f);
                                if(!el.value.trim()){ err.textContent = f.charAt(0).toUpperCase() + f.slice(1) + " is required."; err.style.display="block"; hasError=true; }
                            });
                        }
                        if(digitalSendTo.value === "recipient"){
                            ["name","email","message","from","date"].forEach(f=>{
                                const el = document.getElementById("digital_recipient_"+f);
                                const err = document.getElementById("error_digital_recipient_"+f);
                                if(!el.value.trim()){ err.textContent = f.charAt(0).toUpperCase() + f.slice(1) + " is required."; err.style.display="block"; hasError=true; }
                            });
                        }
                    }

                    if(type.value === "physical"){
                        if(!physicalOption.value){
                            document.getElementById("error_physical_option").textContent = "Please select delivery option.";
                            document.getElementById("error_physical_option").style.display = "block";
                            hasError = true;
                        }
                        if(physicalOption.value === "collect"){
                            ["name","from"].forEach(f=>{
                                const el = document.getElementById("physical_collect_"+f);
                                const err = document.getElementById("error_physical_collect_"+f);
                                if(!el.value.trim()){ err.textContent = f.charAt(0).toUpperCase() + f.slice(1) + " is required."; err.style.display="block"; hasError=true; }
                            });
                        }
                        if(physicalOption.value === "deliver"){
                            ["name","from","address"].forEach(f=>{
                                const el = document.getElementById("physical_deliver_"+f);
                                const err = document.getElementById("error_physical_deliver_"+f);
                                if(!el.value.trim()){ err.textContent = f.charAt(0).toUpperCase() + f.slice(1) + " is required."; err.style.display="block"; hasError=true; }
                            });
                        }
                    }

                    if(hasError){ e.preventDefault(); }
                });

                form.addEventListener("submit", function(){
                    document.querySelectorAll('.voucher-fields [style*="display: none"] input, .voucher-fields [style*="display: none"] textarea, .voucher-fields [style*="display: none"] select').forEach(el=>{
                        el.disabled = true;
                    });
                });
            });
            </script>
            <?php
        }

    // ---------------- CART & ORDER HANDLING ---------------- //
    public function add_voucher_to_cart($cart_item_data, $product_id) {
        $voucher_fields = [
            'voucher_type',
            'digital_send_to',
            'digital_myself_email',
            'digital_myself_name',
            'digital_myself_message',
            'digital_recipient_name',
            'digital_recipient_email',
            'digital_recipient_message',
            'digital_recipient_from',
            'digital_recipient_date',
            'physical_option',
            'physical_collect_name',
            'physical_collect_message',
            'physical_collect_from',
            'physical_deliver_name',
            'physical_deliver_message',
            'physical_deliver_from',
            'physical_deliver_address'
        ];

        foreach ($voucher_fields as $key) {
            if (isset($_POST[$key]) && !empty($_POST[$key])) {
                if ($key === 'digital_recipient_date') {
                    $date = sanitize_text_field($_POST[$key]);
                    $cart_item_data[$key] = $this->validate_date($date) ? date('Y-m-d', strtotime($date)) : '';
                } else {
                    $cart_item_data[$key] = sanitize_text_field($_POST[$key]);
                }
            }
        }
        $cart_item_data['voucher_unique'] = uniqid('voucher_', true);
        return $cart_item_data;
    }

    private function validate_date($date) {
        if (empty($date)) return false;
        $timestamp = strtotime($date);
        return $timestamp && $date === date('Y-m-d', $timestamp);
    }

    public function display_voucher_in_cart($item_data, $cart_item) {
        $display_fields = [
            'voucher_type' => 'Voucher Type',
            'digital_send_to' => 'Send To',
            'digital_myself_email' => 'Email (Myself)',
            'digital_myself_name' => 'Recipient Name (Myself)',
            'digital_myself_message' => 'Message (Myself)',
            'digital_recipient_name' => 'Recipient Name',
            'digital_recipient_email' => 'Recipient Email',
            'digital_recipient_message' => 'Message',
            'digital_recipient_from' => 'From',
            'digital_recipient_date' => 'Send Date',
            'physical_option' => 'Delivery Option',
            'physical_collect_name' => 'Recipient Name (Collect)',
            'physical_collect_message' => 'Message (Collect)',
            'physical_collect_from' => 'From (Collect)',
            'physical_deliver_name' => 'Recipient Name (Deliver)',
            'physical_deliver_message' => 'Message (Deliver)',
            'physical_deliver_from' => 'From (Deliver)',
            'physical_deliver_address' => 'Delivery Address'
        ];

        foreach ($display_fields as $key => $label) {
            if (isset($cart_item[$key]) && !empty($cart_item[$key])) {
                $item_data[] = [
                    'name' => $label,
                    'value' => esc_html($cart_item[$key])
                ];
            }
        }
        return $item_data;
    }

    public function save_voucher_to_order($item, $cart_item_key, $values, $order) {
        $meta_mapping = [
            'voucher_type' => 'Voucher Type',
            'digital_send_to' => 'Send To',
            'digital_myself_email' => 'Email (Myself)',
            'digital_myself_name' => 'Recipient Name (Myself)',
            'digital_myself_message' => 'Message (Myself)',
            'digital_recipient_name' => 'Recipient Name',
            'digital_recipient_email' => 'Recipient Email',
            'digital_recipient_message' => 'Message',
            'digital_recipient_from' => 'From',
            'digital_recipient_date' => 'Send Date',
            'physical_option' => 'Delivery Option',
            'physical_collect_name' => 'Recipient Name (Collect)',
            'physical_collect_message' => 'Message (Collect)',
            'physical_collect_from' => 'From (Collect)',
            'physical_deliver_name' => 'Recipient Name (Deliver)',
            'physical_deliver_message' => 'Message (Deliver)',
            'physical_deliver_from' => 'From (Deliver)',
            'physical_deliver_address' => 'Delivery Address'
        ];

        foreach ($meta_mapping as $key => $label) {
            if (isset($values[$key]) && !empty($values[$key])) {
                $item->add_meta_data($label, $values[$key]);
            }
        }

//         if (isset($values['voucher_unique'])) {
//             $item->add_meta_data('Voucher Unique ID', $values['voucher_unique']);
//         }
    }

    // ---------------- VOUCHER NUMBER ---------------- //
    private function get_next_voucher_number() {
        $current = get_option('wc_voucher_last_number', 0);
        $next = $current + 1;
        update_option('wc_voucher_last_number', $next);
        return str_pad($next, 6, '0', STR_PAD_LEFT);
    }

    // ---------------- PDF GENERATION (Dompdf) ---------------- //
		public function process_voucher_order($order_id) {
			global $wpdb;
			$order = wc_get_order($order_id);
			$table_name = $wpdb->prefix . 'wc_vouchers';

            // Check if this order has already been processed
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table_name} WHERE order_id = %d",
                $order_id
            ));

            if ($existing > 0) {
                error_log("=== VOUCHER ORDER {$order_id} ALREADY PROCESSED - SKIPPING ===");
                return; // Skip processing to prevent duplicates
            }

			error_log("=== PROCESS VOUCHER ORDER: {$order_id} ===");

			foreach ($order->get_items() as $item_id => $item) {
				$voucher_type = $item->get_meta('Voucher Type');
				error_log("Item {$item_id} - Voucher Type: " . $voucher_type);

				if (!$voucher_type) continue;

				$digital_send_to = $item->get_meta('Send To');
				$physical_option = $item->get_meta('Delivery Option');

				$voucher_data = [
					'voucher_type' => $voucher_type,
					'digital_send_to' => $digital_send_to,
					'physical_option' => $physical_option,
					'digital_myself_email' => $item->get_meta('Email (Myself)'),
					'digital_myself_name' => $item->get_meta('Recipient Name (Myself)'),
					'digital_myself_message' => $item->get_meta('Message (Myself)'),
					'digital_recipient_name' => $item->get_meta('Recipient Name'),
					'digital_recipient_email' => $item->get_meta('Recipient Email'),
					'digital_recipient_message' => $item->get_meta('Message'),
					'digital_recipient_from' => $item->get_meta('From'),
					'digital_recipient_date' => $item->get_meta('Send Date'),
					'physical_collect_name' => $item->get_meta('Recipient Name (Collect)'),
					'physical_collect_message' => $item->get_meta('Message (Collect)'),
					'physical_collect_from' => $item->get_meta('From (Collect)'),
					'physical_deliver_name' => $item->get_meta('Recipient Name (Deliver)'),
					'physical_deliver_message' => $item->get_meta('Message (Deliver)'),
					'physical_deliver_from' => $item->get_meta('From (Deliver)'),
					'physical_deliver_address' => $item->get_meta('Delivery Address'),
				];

				error_log("Voucher data extracted: " . print_r($voucher_data, true));

				$recipient_name = '';
				$from_name = '';
				$message = '';
				$recipient_email = '';
				$recipient_date = null;
				$email_scheduled = 0;
				$send_option = '';

				if ($voucher_type === 'digital') {
					$send_option = $digital_send_to;

					if ($digital_send_to === 'myself') {
						$recipient_name = $voucher_data['digital_myself_name'];
						$from_name = $voucher_data['digital_myself_name'];
						$message = $voucher_data['digital_myself_message'];
						$recipient_email = $voucher_data['digital_myself_email'];
					} elseif ($digital_send_to === 'recipient') {
						$recipient_name = $voucher_data['digital_recipient_name'];
						$from_name = $voucher_data['digital_recipient_from'];
						$message = $voucher_data['digital_recipient_message'];
						$recipient_email = $voucher_data['digital_recipient_email'];

						if ($this->validate_date($voucher_data['digital_recipient_date'])) {
							$recipient_date = date('Y-m-d', strtotime($voucher_data['digital_recipient_date']));
							$email_scheduled = 1;
						}
					}
				} elseif ($voucher_type === 'physical') {
					$send_option = $physical_option;

					if ($physical_option === 'collect') {
						$recipient_name = $voucher_data['physical_collect_name'];
						$from_name = $voucher_data['physical_collect_from'];
						$message = $voucher_data['physical_collect_message'];
					} elseif ($physical_option === 'deliver') {
						$recipient_name = $voucher_data['physical_deliver_name'];
						$from_name = $voucher_data['physical_deliver_from'];
						$message = $voucher_data['physical_deliver_message'];
					}
				}

				error_log("Extracted for PDF - To: {$recipient_name}, From: {$from_name}, Message: {$message}");

				$voucher_info = $this->generate_voucher_pdf($order, $item, $voucher_data);

				$wpdb->insert(
					$table_name,
					[
						'order_id' => $order_id,
						'item_id' => $item_id,
						'voucher_number' => $voucher_info['number'],
						'voucher_type' => $voucher_type,
						'send_option' => $send_option,
						'recipient_name' => $recipient_name ?: '',
						'recipient_email' => $recipient_email ?: '',
						'from_name' => $from_name ?: '',
						'message' => $message ?: '',
						'pdf_filename' => $voucher_info['filename'],
						'expiry_date' => $voucher_info['expiry_date'],
						'recipient_date' => $recipient_date,
						'email_scheduled' => $email_scheduled,
					],
					['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
				);

				error_log("Voucher #{$voucher_info['number']} saved successfully");
			}
		}

        public function generate_voucher_pdf($order, $item, $voucher_data) {
            $voucher_number = $this->get_next_voucher_number();
            $purchase_date = $order->get_date_created()->date('Y-m-d');
            $expiry_date = date('Y-m-d', strtotime($purchase_date . ' +1 year'));

            $voucher_type = $voucher_data['voucher_type'] ?? 'digital';

            // Determine send option (digital/physical)
            $send_option = '';
            if ($voucher_type === 'digital') {
                $send_option = !empty($voucher_data['digital_send_to']) ? $voucher_data['digital_send_to'] : '';
            } else {
                $send_option = !empty($voucher_data['physical_option']) ? $voucher_data['physical_option'] : '';
            }

            error_log("PDF Gen Debug - Type: {$voucher_type}, Send Option: {$send_option}");

            // Default values
            $recipient_name = 'Valued Customer';
            $from_name = 'Valued Customer';
            $message = '';

            // Handle digital voucher input
            if ($voucher_type === 'digital') {
                if ($send_option === 'myself') {
                    $recipient_name = !empty($voucher_data['digital_myself_name']) ? $voucher_data['digital_myself_name'] : 'Valued Customer';
                    $from_name = !empty($voucher_data['digital_myself_name']) ? $voucher_data['digital_myself_name'] : 'Valued Customer';
                    $message = !empty($voucher_data['digital_myself_message']) ? $voucher_data['digital_myself_message'] : '';
                } elseif ($send_option === 'recipient') {
                    $recipient_name = !empty($voucher_data['digital_recipient_name']) ? $voucher_data['digital_recipient_name'] : 'Valued Customer';
                    $from_name = !empty($voucher_data['digital_recipient_from']) ? $voucher_data['digital_recipient_from'] : 'Valued Customer';
                    $message = !empty($voucher_data['digital_recipient_message']) ? $voucher_data['digital_recipient_message'] : '';
                }
            }

            // Handle physical voucher input
            elseif ($voucher_type === 'physical') {
                if ($send_option === 'collect') {
                    $recipient_name = !empty($voucher_data['physical_collect_name']) ? $voucher_data['physical_collect_name'] : 'Valued Customer';
                    $from_name = !empty($voucher_data['physical_collect_from']) ? $voucher_data['physical_collect_from'] : 'Valued Customer';
                    $message = !empty($voucher_data['physical_collect_message']) ? $voucher_data['physical_collect_message'] : '';
                } elseif ($send_option === 'deliver') {
                    $recipient_name = !empty($voucher_data['physical_deliver_name']) ? $voucher_data['physical_deliver_name'] : 'Valued Customer';
                    $from_name = !empty($voucher_data['physical_deliver_from']) ? $voucher_data['physical_deliver_from'] : 'Valued Customer';
                    $message = !empty($voucher_data['physical_deliver_message']) ? $voucher_data['physical_deliver_message'] : '';
                }
            }

            error_log("PDF Gen - To: {$recipient_name}, From: {$from_name}, Message: {$message}");

            // Voucher details
            $amount = $order->get_item_total($item, true, true);
            $product_name = $item->get_name();

            // Generate HTML for PDF
            $html = $this->get_voucher_html_template(
                $voucher_number,
                $recipient_name,
                $from_name,
                $message,
                $product_name,
                $amount,
                $expiry_date
            );

            // Setup Dompdf
            $options = new \Dompdf\Options();
            $options->set('isRemoteEnabled', true);

            $dompdf = new \Dompdf\Dompdf($options);
            $dompdf->loadHtml($html);
             $dompdf->set_paper([0, 0, 500, 690], 'portrait');
            $dompdf->render();

            // Upload directory for vouchers
            $upload_dir = wp_upload_dir();
            $voucher_dir = $upload_dir['basedir'] . '/vouchers/';
            if (!file_exists($voucher_dir)) {
                wp_mkdir_p($voucher_dir);
            }

            $filename = 'voucher-' . $voucher_number . '-' . time() . '.pdf';
            $filepath = $voucher_dir . $filename;

            // Save PDF file
            file_put_contents($filepath, $dompdf->output());

            // Save metadata to order item
            $item->add_meta_data('_voucher_number', $voucher_number);
            $item->add_meta_data('_voucher_pdf', $filename);
            $item->add_meta_data('_voucher_expiry', $expiry_date);
            $item->save();

            // Return voucher info
            return [
                'filepath' => $filepath,
                'filename' => $filename,
                'number' => $voucher_number,
                'expiry_date' => $expiry_date
            ];
        }


private function get_voucher_html_template($voucher_number, $to, $from, $message, $product, $amount, $expiry) {
    // Sanitize input
    $to = htmlspecialchars($to, ENT_QUOTES, 'UTF-8');
    $from = htmlspecialchars($from, ENT_QUOTES, 'UTF-8');
    $message = nl2br(htmlspecialchars($message, ENT_QUOTES, 'UTF-8'));
    $product = htmlspecialchars($product, ENT_QUOTES, 'UTF-8');
    $voucher_number = htmlspecialchars($voucher_number, ENT_QUOTES, 'UTF-8');
    $expiry = htmlspecialchars($expiry, ENT_QUOTES, 'UTF-8');
    $symbal = '£';
    $amount = htmlspecialchars($amount, ENT_QUOTES, 'UTF-8');

  $html = <<<HTML
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <title>Pretty Woman Spa - Gift Voucher</title>
        <style>
        @page { margin: 0; }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #000;
            color: #fff;
        }
        .voucher {
            width: 100%;  
            margin: 0 auto;
            background: #000;
        }
        .voucher-header {
            text-align: center;
            padding: 20px 0 10px; 
        }
        .voucher-header img {
            width: 50%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
        .address {
            font-size: 16px; 
            margin-top: 10px; 
            line-height: 1.4; 
            color: #f1dfa0;
        }
        .gift-bar {
            background: #ff6600;
            color: #000;
            font-weight: bold;
            text-align: center;
            padding: 10px 0; 
            font-size: 40px; 
            letter-spacing: 0.8px; 
        }
        .voucher-body {
            display: table;
            width: 100%;
            background: #000;
        }
        .voucher-image, .voucher-form {
            display: table-cell;
            vertical-align: top;
        }
        .voucher-image {
            width: 40%;
        }
        .voucher-image img {
            width: 100%;
            height: 580px; 
            display: block;
        }
        .voucher-form {
            width: 60%;
            background: #fff;
            color: #000;
            box-sizing: border-box;
        }
        .voucher-form .main-form {
            padding: 15px 20px; 
        }
        .voucher-form .logo-box {
            margin-bottom: 15px; 
            background: #000;
            padding: 20px 15px; 
            text-align: center;
        }
        .voucher-form .logo-box img {
            width: 60%; 
            height: auto;
            display: block;
        }
        .voucher-form p {
            margin: 8px 0; 
            font-size: 13px; 
            line-height: 1.6; 
        }
        .voucher-form .line {
            border-bottom: 1.5px solid #000; 
            width: 100%;
            display: block;
            margin-bottom: 10px;
        }
        .voucher-form .label {
            font-weight: bold;
            color: #000;
            font-size: 18px; 
            margin-bottom: 3px; 
            display: block;
        }
        .voucher-form .email {
            color: #ff6600;
            font-weight: bold;
            margin-top: 15px; 
            font-size: 12px; 
            float: right;
            background: #fff;
        }
        </style>
        </head>
        <body>
        <div class="voucher">
            <div class="voucher-header">
                <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/05/prettywomanspa-logo.svg" alt="Logo">
                <p class="address">
                    Palace Hotel,<br>
                    8 Ness Walk,<br>
                    Inverness<br>
                    IV3 5NG
                </p>
            </div>

            <div class="gift-bar">GIFT VOUCHER #{$voucher_number}</div>

            <div class="voucher-body">
                <div class="voucher-image">
                    <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/10/pdfimg.png" alt="Spa image">
                </div>

                <div class="voucher-form">
                    <div class="logo-box">
                        <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/05/prettywomanspa-logo.svg" alt="Logo">
                    </div>
                    <div class="main-form">
                        <span class="label">To:</span>
                        <p>{$to}</p>
                        <span class="line"></span>

                        <span class="label">From:</span>
                        <p>{$from}</p>
                        <span class="line"></span>

                        <span class="label">Amount/Treatment:</span>
                       <!-- <p>{$symbal}{$amount} - {$product}</p> -->
                        <p>{$product}</p>
                        <span class="line"></span>

                        <span class="label">Expiry Date:</span>
                        <p>{$expiry}</p>
                        <span class="line"></span>

                        <span class="label">Message:</span>
                        <p>{$message}</p>
                        <span class="line"></span>

                        <p class="email">info@prettywomanspa.co.uk</p>
                    </div>
                </div>
            </div>
        </div>
        </body>
        </html>
        HTML;

    return $html;
}



public function send_voucher_email($order_id) {
    global $wpdb;
    
    $order = wc_get_order($order_id);
    if (!$order) {
        error_log("=== SEND VOUCHER EMAIL: {$order_id} - INVALID ORDER ===");
        return;
    }
    
    $table_name = $wpdb->prefix . 'wc_vouchers';
    
    // Check for vouchers that haven't had emails sent yet
    $vouchers = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE order_id = %d AND email_scheduled = 0 AND recipient_email != ''",
        $order_id
    ));
    
    if (empty($vouchers)) {
        error_log("=== SEND VOUCHER EMAIL: {$order_id} - NO ELIGIBLE VOUCHERS OR ALREADY SENT ===");
        return;
    }
    
    error_log('send_voucher_email triggered for order: ' . $order_id);
    
    foreach ($order->get_items() as $item_id => $item) {
        $voucher_pdf = $item->get_meta('_voucher_pdf');
        error_log('voucher_pdf: ' . $voucher_pdf);
        
        if (!$voucher_pdf) continue;
        
        $upload_dir = wp_upload_dir();
        $pdf_path = $upload_dir['basedir'] . '/vouchers/' . $voucher_pdf;
        
        if (!file_exists($pdf_path)) {
            error_log("Voucher PDF not found: $pdf_path");
            continue;
        }
        
        $digital_send_to = $item->get_meta('Send To');
        $send_date = $item->get_meta('Send Date');
        
        // Skip if sending to recipient AND date is set (regardless of when)
        if ($digital_send_to === 'recipient' && !empty($send_date) && $this->validate_date($send_date)) {
            error_log("Voucher has scheduled send date, skipping immediate send (order: {$order_id}, item: {$item_id}, date: {$send_date})");
            continue; // Skip sending entirely - will be handled by scheduled job
        }
        
        // Prepare email details
        if ($digital_send_to === 'myself') {
            $to_email = $item->get_meta('Email (Myself)');
            $recipient_name = $item->get_meta('Recipient Name (Myself)') ?: 'Valued Customer';
            $from_name = $item->get_meta('Recipient Name (Myself)') ?: 'Valued Customer';
        } elseif ($digital_send_to === 'recipient') {
            $to_email = $item->get_meta('Recipient Email');
            $recipient_name = $item->get_meta('Recipient Name') ?: 'Valued Customer';
            $from_name = $item->get_meta('From') ?: 'Valued Customer';
        } else {
            continue;
        }
        
        if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) {
            error_log("Invalid email: $to_email");
            continue;
        }
        
        // Prepare email
        $subject = 'Your Pretty Woman Spa Voucher';
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        $attachments = [$pdf_path];
        
        $body = "
            <p>Hi {$recipient_name},</p>
            <p>You've received a voucher for Pretty Woman Spa from {$from_name}.</p>
            <p>Please see it attached.</p>
            <p>Any issues, please contact <a href='mailto:info@prettywomanspa.co.uk'>info@prettywomanspa.co.uk</a>.</p>
            <p>We hope to see you soon.</p>
            <p>The Team at Pretty Woman Spa</p>
        ";
        
        $mail_sent = wp_mail($to_email, $subject, $body, $headers, $attachments);
        
        error_log("Email sent to $to_email: " . ($mail_sent ? 'YES' : 'NO'));
    }
}

    public function custom_email_content($order, $sent_to_admin, $plain_text, $email) {
        if ($email->id === 'customer_completed_order') {
            foreach ($order->get_items() as $item) {
                $pdf = $item->get_meta('_voucher_pdf');
                if ($pdf) {
                    $upload_dir = wp_upload_dir();
                    $file_url = $upload_dir['baseurl'] . '/vouchers/' . $pdf;
                    echo '<p><a href="' . esc_url($file_url) . '" target="_blank">Download your voucher PDF</a></p>';
                }
            }
        }
    }

    // ---------------- ADMIN SETTINGS ---------------- //
    public function add_admin_menu() {
        add_submenu_page('woocommerce', 'Voucher', 'Voucher', 'manage_options', 'wc-voucher-settings', [$this, 'settings_page']);
    }

    public function register_settings() {
        register_setting('wc_voucher_options', 'wc_voucher_last_number');
    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Voucher</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('wc_voucher_options');
                do_settings_sections('wc_voucher_options');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Last Voucher Number</th>
                        <td>
                            <input type="number" name="wc_voucher_last_number" value="<?php echo esc_attr(get_option('wc_voucher_last_number', 0)); ?>" />
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

new WooCommerce_Voucher_System();

function maybe_create_voucher_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'wc_vouchers';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        order_id BIGINT UNSIGNED NOT NULL,
        item_id BIGINT UNSIGNED NOT NULL,
        voucher_number VARCHAR(20) NOT NULL,
        voucher_type VARCHAR(20) DEFAULT '',
        send_option VARCHAR(50) DEFAULT '',
        recipient_name VARCHAR(255) DEFAULT '',
        recipient_email VARCHAR(255) DEFAULT '',
        from_name VARCHAR(255) DEFAULT '',
        message TEXT,
        pdf_filename VARCHAR(255),
        expiry_date DATE,
        recipient_date DATE,
        email_scheduled TINYINT(1) DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
// add_action('init', 'maybe_create_voucher_table');

// Trigger custom email when order is created
// Trigger custom email when order is created
add_action('woocommerce_thankyou', 'send_custom_processing_email', 10, 1);
function send_custom_processing_email($order_id) {
    // Prevent duplicate emails
    if (get_post_meta($order_id, '_custom_email_sent', true)) {
        return;
    }
    
    // Get the order object
    $order = wc_get_order($order_id);
    
    if (!$order) {
        return;
    }
    
    // Only send for specific order statuses (processing, pending, on-hold)
    $allowed_statuses = array('processing', 'pending', 'on-hold');
    
    if (!in_array($order->get_status(), $allowed_statuses)) {
        return;
    }
    
    // Check if order has items
    if (count($order->get_items()) === 0) {
        return;
    }
    
    // Get WooCommerce mailer
    $mailer = WC()->mailer();
    
    // Get customer details
    $customer_email = $order->get_billing_email();
    $customer_name = $order->get_billing_first_name();
    
    // Email subject
    $subject = sprintf('Thank you very much for your order');
    
    // Email heading
    $heading = 'Order Summary';
    
    // Build email content
    $email_content = custom_processing_email_html($order, $customer_name, $heading);
    
    // Wrap content in WooCommerce email template
    $message = $mailer->wrap_message($heading, $email_content);
    
    // Send email
    $sent = $mailer->send($customer_email, $subject, $message);
    
    // Mark email as sent to prevent duplicates
    if ($sent) {
        update_post_meta($order_id, '_custom_email_sent', 'yes');
    }
}

// Generate custom email HTML content
function custom_processing_email_html($order, $customer_name, $heading) {
    ob_start();
    
    // Get order items
    $items = $order->get_items();
    
    ?>
    
    <p>Hi <?php echo esc_html($customer_name); ?>,</p>

    <p>Thank you very much for your order.</p>

    <p>If you've ordered a gift voucher for delivery, this will be dispatched shortly.</p>

    <p>If you've ordered a gift voucher for collection, please collect from 
        <strong>The Palace Hotel Main Reception - 8 Ness Walk, Inverness IV3 5NG</strong>. 
        (Please note that we aim to have your gift voucher ready within 24 hours. 
        You'll receive a confirmation email once your voucher is ready to collect. 
        Please wait for this email before coming to collect.)
    </p>
        <p>If you've ordered a digital gift voucher, it will be emailed to your chosen recipient email on your chosen date.</p>

    <p>Please see your order details below:</p>
    
    <h2 style="color: #96588a; display: block; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-align: left;">
        Order Summery
    </h2>
    
    <?php if (!empty($items)): ?>
    <div style="margin-bottom: 40px;">
        <table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; color: #636363; border: 1px solid #e5e5e5;" border="1">
            <thead>
                <tr>
                    <th class="td" scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Product</th>
                    <th class="td" scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Quantity</th>
                    <th class="td" scope="col" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Price</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($items as $item_id => $item) {
                    $product = $item->get_product();
                    $product_name = $item->get_name();
                    ?>
                    <tr>
                        <td class="td" style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; word-wrap: break-word;">
                            <?php echo esc_html($product_name); ?>
                            <?php
                            $item_meta = $item->get_meta_data();
                            if (!empty($item_meta)) {
                                echo '<br><small style="color: #777;">';
                                foreach ($item_meta as $meta) {
                                    $meta_data = $meta->get_data();
                                    $meta_key = $meta_data['key'];
                                    
                                    // Skip hidden meta keys (starting with underscore) and pa_size
                                    if ($meta_key && $meta_data['value'] 
                                        && strpos($meta_key, '_') !== 0 
                                        && $meta_key !== 'pa_size') {
                                        echo esc_html($meta_key . ': ' . $meta_data['value']) . '<br>';
                                    }
                                }
                                echo '</small>';
                            }
                            ?>
                        </td>
                        <td class="td" style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                            <?php echo esc_html($item->get_quantity()); ?>
                        </td>
                        <td class="td" style="color: #636363; border: 1px solid #e5e5e5; padding: 12px; text-align: left; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                            <?php echo $order->get_formatted_line_subtotal($item); ?>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <th class="td" scope="row" colspan="2" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Subtotal:</th>
                    <td class="td" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php echo $order->get_subtotal_to_display(); ?></td>
                </tr>
                <?php if ($order->get_total_shipping() > 0): ?>
                <tr>
                    <th class="td" scope="row" colspan="2" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Shipping:</th>
                    <td class="td" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php echo $order->get_shipping_to_display(); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($order->get_total_tax() > 0): ?>
                <tr>
                    <th class="td" scope="row" colspan="2" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Tax:</th>
                    <td class="td" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php echo wc_price($order->get_total_tax()); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <th class="td" scope="row" colspan="2" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;">Payment method:</th>
                    <td class="td" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left;"><?php echo esc_html($order->get_payment_method_title()); ?></td>
                </tr>
                <tr>
                    <th class="td" scope="row" colspan="2" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left; font-size: 1.2em;">Total:</th>
                    <td class="td" style="color: #636363; border: 1px solid #e5e5e5; vertical-align: middle; padding: 12px; text-align: left; font-size: 1.2em;"><strong><?php echo $order->get_formatted_order_total(); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php else: ?>
        <p>No items found in this order.</p>
    <?php endif; ?>
    
    <?php
    // Display order-level custom meta data
    $order_meta = $order->get_meta_data();
    if (!empty($order_meta)) {
        $has_visible_meta = false;
        $visible_meta = array();
        
        foreach ($order_meta as $meta) {
            $meta_data = $meta->get_data();
            // Check if there's any visible meta (not starting with underscore)
            if ($meta_data['key'] && $meta_data['value'] && strpos($meta_data['key'], '_') !== 0) {
                $has_visible_meta = true;
                $visible_meta[] = $meta_data;
            }
        }
    }
    ?>
    
    <table id="addresses" cellspacing="0" cellpadding="0" style="width: 100%; vertical-align: top; margin-bottom: 40px; padding: 0;" border="0">
        <tr>
            <td style="text-align: left; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; border: 0; padding: 0;" valign="top" width="50%">
                <h2 style="color: #96588a; display: block; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-align: left;">Billing address</h2>
                <address class="address">
                    <?php echo wp_kses_post($order->get_formatted_billing_address()); ?>
                    <?php if ($order->get_billing_phone()) : ?>
                        <br/><?php echo esc_html($order->get_billing_phone()); ?>
                    <?php endif; ?>
                    <?php if ($order->get_billing_email()) : ?>
                        <br/><?php echo esc_html($order->get_billing_email()); ?>
                    <?php endif; ?>
                </address>
            </td>
            <?php if ($order->get_formatted_shipping_address()) : ?>
            <td style="text-align: left; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; border: 0; padding: 0;" valign="top" width="50%">
                <h2 style="color: #96588a; display: block; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 0 0 18px; text-align: left;">Shipping address</h2>
                <address class="address">
                    <?php echo wp_kses_post($order->get_formatted_shipping_address()); ?>
                </address>
            </td>
            <?php endif; ?>
        </tr>
    </table>
    
    <p>If you need any help with your order, please contact us at 
        <a href="mailto:info@prettywomanspa.co.uk">info@prettywomanspa.co.uk</a>.
    </p>

    <p>Thanks again,<br>The Team at Pretty Woman Spa</p>
    
    <?php
    return ob_get_clean();
}

// Optional: Disable default WooCommerce processing email to avoid duplicate
add_filter('woocommerce_email_enabled_customer_processing_order', '__return_false', 10, 2);

 



add_action('admin_menu', 'add_vouchers_download_admin_menu');

function add_vouchers_download_admin_menu() {
    add_submenu_page(
        'woocommerce',
        'Vouchers Download',
        'Vouchers Download',
        'manage_woocommerce',
        'vouchers-download',
        'vouchers_download_page_callback'
    );
}

function vouchers_download_page_callback() {
    $upload_dir = wp_upload_dir();
    $voucher_dir = $upload_dir['basedir'] . '/vouchers';
    $voucher_url = $upload_dir['baseurl'] . '/vouchers';

    $files_per_page = 10;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $search_order_id = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    echo '<div class="wrap">';
    echo '<h1 class="wp-heading-inline">📄 Vouchers Download</h1>';

    // 🔍 Search form
    echo '<form method="get" action="" style="margin-top: 20px; margin-bottom: 20px; float: right;">';
    echo '<input type="hidden" name="page" value="vouchers-download" />';
    echo '<input type="text" name="s" placeholder="Search Order ID..." value="' . esc_attr($search_order_id) . '" />';
    echo '<input type="submit" class="button" value="Search" />';
    echo '</form>';

    if (!file_exists($voucher_dir)) {
        echo '<div class="notice notice-warning"><p>⚠️ Folder not found: ' . esc_html($voucher_dir) . '</p></div>';
        echo '</div>';
        return;
    }

    $all_files = glob($voucher_dir . '/*.pdf') ?: [];

    // Filter by Order ID if provided
    if (!empty($search_order_id)) {
        $all_files = array_filter($all_files, function ($file) use ($search_order_id) {
            return preg_match('/voucher-\d+-' . preg_quote($search_order_id, '/') . '\.pdf$/', basename($file));
        });
    }

    // Sort files by modified time DESC
    usort($all_files, function ($a, $b) {
        return filemtime($b) - filemtime($a);
    });

    $total_files = count($all_files);
    $total_pages = ceil($total_files / $files_per_page);

    if ($total_files === 0) {
        echo '<div class="notice notice-info"><p>📂 No matching PDF vouchers found.</p></div>';
        echo '</div>';
        return;
    }

    $start_index = ($current_page - 1) * $files_per_page;
    $paged_files = array_slice($all_files, $start_index, $files_per_page);

    // Table
    echo '<table class="widefat fixed striped">';
    echo '<thead><tr><th>Order ID</th><th>Date</th><th>Download</th></tr></thead>';
    echo '<tbody>';

    foreach ($paged_files as $file) {
        $filename = basename($file);
        $file_url = $voucher_url . '/' . $filename;
        $file_date = date('d M Y', filemtime($file));

        echo '<tr>';

        // Extract order ID from file name
        if (preg_match('/voucher-\d+-(\d+)\.pdf$/', $filename, $matches)) {
            $order_id = $matches[1];
            echo '<td>' . esc_html($order_id) . '</td>';
        } else {
            echo '<td>No order found</td>';
        }

        echo '<td>' . esc_html($file_date) . '</td>';
        echo '<td><a href="' . esc_url($file_url) . '" class="button button-primary" target="_blank">Download</a></td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';

    // Pagination
    $pagination_html = '<div class="tablenav"><div class="tablenav-pages"><span class="pagination-links">';
    $base_url = admin_url('admin.php?page=vouchers-download');
    if (!empty($search_order_id)) {
        $base_url = add_query_arg('s', $search_order_id, $base_url);
    }

    if ($current_page > 1) {
        $pagination_html .= '<a class="prev-page button" href="' . esc_url(add_query_arg('paged', $current_page - 1, $base_url)) . '">‹ Prev</a> ';
    }

    for ($i = 1; $i <= $total_pages; $i++) {
        if ($i == $current_page) {
            $pagination_html .= '<span class="button current-page" style="background: #2271b1; color: white;">' . $i . '</span> ';
        } else {
            $pagination_html .= '<a class="button" href="' . esc_url(add_query_arg('paged', $i, $base_url)) . '">' . $i . '</a> ';
        }
    }

    if ($current_page < $total_pages) {
        $pagination_html .= '<a class="next-page button" href="' . esc_url(add_query_arg('paged', $current_page + 1, $base_url)) . '">Next ›</a>';
    }

    $pagination_html .= '</span></div></div>';
    echo $pagination_html;

    echo '</div>'; 
}




// // Exit if accessed directly
// if (!defined('ABSPATH')) exit;

// // Load Dompdf library
// require_once __DIR__ . '/vendor/autoload.php';

// // use Dompdf\Dompdf;
// // use Dompdf\Options;

// /**
//  * Shortcode to generate Pretty Woman Spa voucher PDF
//  */
function prettywoman_voucher_shortcode() {

    if (ob_get_length()) ob_end_clean();

    // Example dynamic values
    $to = 'John Doe';
    $from = 'Jane Smith';
    $amount = '£100 - Massage';
    $expiry = '31/12/2025';
    $message ="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliq"; 

                $html = <<<HTML
            <!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <title>Pretty Woman Spa - Gift Voucher</title>
            <style>
            @page { margin: 0; }
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background: #000;
                color: #fff;
            }
            .voucher {
                width: 100%;  
                margin: 0 auto;
                background: #000;
            }
            .voucher-header {
                text-align: center;
                padding: 20px 0 10px; 
            }
            .voucher-header img {
                width: 50%;
                height: auto;
                display: block;
                margin: 0 auto;
            }
            .address {
                font-size: 16px; 
                margin-top: 10px; 
                line-height: 1.4; 
                color: #f1dfa0;
            }
            .gift-bar {
                background: #ff6600;
                color: #000;
                font-weight: bold;
                text-align: center;
                padding: 10px 0; 
                font-size: 50px; 
                letter-spacing: 0.8px; 
            }
            .voucher-body {
                display: table;
                width: 100%;
                background: #000;
            }
            .voucher-image, .voucher-form {
                display: table-cell;
                vertical-align: top;
            }
            .voucher-image {
                width: 40%;
            }
            .voucher-image img {
                width: 100%;
                height: 580px; 
                display: block;
            }
            .voucher-form {
                width: 60%;
                background: #fff;
                color: #000;
                box-sizing: border-box;
            }
            .voucher-form .main-form {
                padding: 15px 20px; 
            }
            .voucher-form .logo-box {
                margin-bottom: 15px; 
                background: #000;
                padding: 20px 15px; 
                text-align: center;
            }
            .voucher-form .logo-box img {
                width: 60%; 
                height: auto;
                display: block;
            }
            .voucher-form p {
                margin: 8px 0; 
                font-size: 13px; 
                line-height: 1.6; 
            }
            .voucher-form .line {
                border-bottom: 1.5px solid #000; 
                width: 100%;
                display: block;
                margin-bottom: 10px;
            }
            .voucher-form .label {
                font-weight: bold;
                color: #000;
                font-size: 18px; 
                margin-bottom: 3px; 
                display: block;
            }
            .voucher-form .email {
                color: #ff6600;
                font-weight: bold;
                margin-top: 15px; 
                font-size: 12px; 
                float: right;
                background: #fff;
            }
            </style>
            </head>
            <body>
            <div class="voucher">
                <div class="voucher-header">
                    <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/05/prettywomanspa-logo.svg" alt="Logo">
                    <p class="address">
                        Palace Hotel,<br>
                        8 Ness Walk,<br>
                        Inverness<br>
                        IV3 5NG
                    </p>
                </div>

                <div class="gift-bar">GIFT VOUCHER</div>

                <div class="voucher-body">
                    <div class="voucher-image">
                        <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/10/pdfimg.png" alt="Spa image">
                    </div>

                    <div class="voucher-form">
                        <div class="logo-box">
                            <img src="https://prettywomanspa.co.uk/wp-content/uploads/2025/05/prettywomanspa-logo.svg" alt="Logo">
                        </div>
                        <div class="main-form">
                            <span class="label">To:</span>
                            <p>{$to}</p>
                            <span class="line"></span>

                            <span class="label">From:</span>
                            <p>{$from}</p>
                            <span class="line"></span>

                            <span class="label">Amount/Treatment:</span>
                            <p>{$amount}</p>
                            <span class="line"></span>

                            <span class="label">Expiry Date:</span>
                            <p>{$expiry}</p>
                            <span class="line"></span>

                            <span class="label">Message:</span>
                            <p>{$message}</p>
                            <span class="line"></span>

                            <p class="email">info@prettywomanspa.co.uk</p>
                        </div>
                    </div>
                </div>
            </div>
            </body>
            </html>
            HTML;

    $options = new Options();
    $options->set('isRemoteEnabled', true);

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($html);
     $dompdf->set_paper([0, 0, 510, 698], 'portrait');
    $dompdf->render();

    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="voucher.pdf"');
    header('Cache-Control: public, must-revalidate, max-age=0');
    header('Pragma: public');
    header('Expires: 0');

    echo $dompdf->output();
    exit;
}

add_shortcode('voucher_pdf', 'prettywoman_voucher_shortcode');

// Change default "From" email
add_filter('wp_mail_from', function($original_email_address) {
    return 'notifications@adderbusiness.co.uk';
});

// Change default "From" name
add_filter('wp_mail_from_name', function($original_email_from) {
    return 'Pretty Woman Spa';
});

add_action('template_redirect', function() {
    if (is_shop()) {
        wp_redirect(home_url());
        exit;
    }
});

